document.addEventListener('DOMContentLoaded', () => {
    const messagesContainer = document.getElementById('messages');
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');

    // Function to add a message to the chat
    function addMessage(content, fromMe = false) {
        const message = document.createElement('div');
        message.className = `message ${fromMe ? 'fromMe' : ''}`;
        message.textContent = content;
        messagesContainer.appendChild(message);
        messagesContainer.scrollTop = messagesContainer.scrollHeight; // Auto-scroll to bottom
    }

    // Function to generate a reply based on the user's message
    function generateReply(userMessage) {
        // Normalize user message to lowercase for comparison
        const normalizedMessage = userMessage.toLowerCase();

        // Specific responses for certain messages
        const specificResponses = {
            "hello": "Hi there! How can I assist you today?",
            "thanks": "You're welcome!",
            "bye": "Goodbye! Have a great day!",
            "how are you": "I'm just a bot, but I'm doing great. How can I help you?",
            "what's your name": "I'm a chatbot created for this demo. What can I do for you?",
            "what is your purpose": "I'm here to assist you with information and answer your questions.",
            "help": "Sure, I can help! What do you need assistance with?",
            "joke": "Why don't scientists trust atoms? Because they make up everything!",
          "raj": "he's my kindest friend from the college",
           "virendra": "Brother from another mother",
           "hitesh": "Sabse bekar dost 🤡",
           "jay": "aacha aadmi he par kus bol nai sakta 😊",
           "vatsal": "aacha dost he",
           "jitendra": "he was create me so i thenks to jitendra",
           "utsav": "nigga",
           "chhoti": "data not found 😅😅",
          "song": "tu ga le bhai mere ko nai aat 🌟", 
        
        };

        // Large array of default responses
        const defaultResponses = [
            "I'm here to help!",
            "Tell me more about that.",
            "That sounds interesting.",
            "How can I assist you further?",
            "Could you provide more details?",
            "I'm not sure about that.",
            "Interesting! Can you explain further?",
            "I see. What else can you tell me?",
            "That's an intriguing point.",
            "Can you elaborate on that?",
            "What do you mean by that?",
            "Let's talk more about it.",
            "How does that make you feel?",
            "I'm curious, tell me more!",
            "I'd like to hear more about that.",
            "Do you have any other thoughts on this?",
            "What other information can I provide?",
            "Is there anything else you'd like to know?",
            "Can I assist you with anything else?",
            "Let's explore that topic further.",
            "That's an interesting perspective.",
            "What other questions do you have?",
            "Can you share more details?",
            "I'm here to listen.",
            "What else is on your mind?",
            "I'd love to hear more about that.",
            "Is there anything specific you need help with?",
            "Can you give me more context?",
            "Tell me more about what you're thinking.",
            "How can I be of assistance?",
            "I'm eager to hear more!",
            "What else can we discuss?",
            "How do you feel about that?",
            "What's your take on this?",
            "Let's dive deeper into that.",
            "I'm interested in your viewpoint.",
            "What other topics interest you?",
            "How does this affect you?",
            "What are your thoughts on this?",
            "Let's continue this conversation.",
            "Can you provide more insight?",
            "What else would you like to talk about?",
            "How can I assist you today?",
            "Do you have any other questions?",
            "I'm here to help with anything you need.",
            "What can I do for you right now?",
            "Let's discuss this further.",
            "How can I make this better for you?",
            "Tell me more about your needs.",
            "What are you thinking about?",
            "How can I support you?",
            "Is there something specific you need?",
            "What other information can I offer?",
            "I'm all ears. What do you need?",
            "How can I be of service?",
            "What questions do you have for me?",
            "I'm ready to assist with anything.",
            "What would you like to explore?",
            "Can I offer any more details?",
            "What else should we talk about?",
            "How can I improve this experience for you?",
            "What other areas can we cover?",
            "What can we dive into next?",
            "How else can I be of service?",
            "What other areas are you interested in?",
            "How can I be more helpful to you?",
            "Is there anything else I can address?",
            "What further information can I give you?",
            "How else can I assist you today?",
            "What other inquiries do you have?",
            "Can I provide more details on this?",
            "What additional assistance can I offer?",
            "How can I make things easier for you?",
            "What other subjects would you like to cover?",
            "How can I make this better for you?",
            "Is there anything else I can help with?",
            "What can I provide you with right now?",
            "What more would you like to discuss?",
            "How can I support your needs further?",
            "What other topics are you curious about?",
            "How can I assist with your questions?",
            "What else can I help you with today?",
            "Is there more information you need?",
            "What other details can I provide?",
            "How can I further help you?",
            "What additional insights can I offer?",
            "Is there anything else on your mind?",
            "How else can I be of assistance?",
            // Repeat or modify the above entries to reach a total of 1000+ responses
            // You may want to programmatically generate additional responses or use an external data file
        ];

        // Return a specific response if available
        if (specificResponses[normalizedMessage]) {
            return specificResponses[normalizedMessage];
        }

        // Return a random default response
        return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
    }

    // Event listener for the send button
    sendButton.addEventListener('click', () => {
        const content = messageInput.value.trim();
        if (content) {
            addMessage(content, true); // Add user's message
            messageInput.value = ''; // Clear input field

            // Simulate receiving a response after a delay
            setTimeout(() => {
                const reply = generateReply(content);
                addMessage(reply);
            }, 1000); // Simulated delay for response
        }
    });

    // Optional: Handle "Enter" key for sending messages
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            sendButton.click();
        }
    });
});
